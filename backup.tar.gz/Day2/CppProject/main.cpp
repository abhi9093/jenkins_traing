#include "hello.h"

int main ( void ) {

	Hello obj;
	cout << obj.sayHello 
             << endl;

	return 0;
}
