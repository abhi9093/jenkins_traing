#ifndef __HELLO_H
#define __HELLO_H

#include <iostream>
#include <string>
using namespace std;

class Hello {
public:
	string sayHello();
};

#endif /* __HELLO_H **/
