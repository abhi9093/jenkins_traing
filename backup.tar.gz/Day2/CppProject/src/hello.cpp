#include "hello.h"

string Hello::sayHello() {
   return "Hello C++!";
}
